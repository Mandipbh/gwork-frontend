import 'package:flutter/material.dart';

class InvoiceViewScreen extends StatelessWidget {
  const InvoiceViewScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        // body: SfPdfViewer.network(
        //     'https://cdn.syncfusion.com/content/PDFViewer/flutter-succinctly.pdf',
        //     enableDocumentLinkAnnotation: false)
        );
  }
}
