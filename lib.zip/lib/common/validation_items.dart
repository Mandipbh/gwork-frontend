class ValidationItems {
  final String value;
  final String error;

  ValidationItems(this.value, this.error);
}
